# 🎙️ 录音 Skill — 实时录音+转写+会议处理

> 来自 Vivian 的工作流。说一句"录音，XX"就开始录音，说"停"就停，自动转写 + 出会议纪要。

---

## 这是什么

一个 Claude Code 的 skill，用 Mac 麦克风实时录音，边录边转写（Whisper 本地跑，不上云），录完自动生成：
- 内部版会议纪要
- 客户版会议纪要
- 朋友圈文案
- 跟进任务清单

全程只需要说两句话：**"录音，XX"** 和 **"停"**。

---

## 安装（三步）

### 1. 把文件放进你的 vault

把这个包里的两个文件，放到你 vault 的相同位置：

```
你的vault/
├── .claude/skills/recording/SKILL.md    ← 从本包复制
└── _tools/live_transcribe.py            ← 从本包复制
```

如果你的 vault 里没有 `.claude/skills/` 或 `_tools/` 文件夹，直接新建。

### 2. 装依赖

打开 Claude Code，进入你的 vault 目录，跟 CC 说：

> 装一下录音 skill 的依赖

CC 会自动执行：
```bash
pip install openai-whisper SpeechRecognition pyaudio numpy
brew install ffmpeg portaudio
```

跑不通的话，把报错丢给 CC，让 CC 判断缺啥。

### 3. 第一次授予麦克风权限

macOS 首次运行脚本时会弹窗问"是否允许终端访问麦克风"，点允许。

---

## 怎么用

### 开会时

跟 CC 说：

> 录音，张三

CC 会启动录音，屏幕上边录边出文字。开完会说：

> 停

CC 自动停止录音，读转写文本，然后出会议纪要、朋友圈、跟进任务（如果你把流水线②也一起装了）。

### 已经录好的音频文件

直接把音频文件（mp3/m4a/wav 都行）丢给 CC，说"这是和 XX 的录音"，CC 会离线转写 + 处理。

---

## 如果你的 vault 结构不一样

脚本默认把录音存到 `01-一号位AI进化论/07-沟通录音/`（这是 Vivian 的文件夹结构）。你的肯定不一样，两种办法：

- **临时用**：启动时加参数 `--output-dir "你的路径"`
- **长期改**：跟 CC 说"把录音 skill 的默认输出路径改成 XXX"，CC 会改 `live_transcribe.py` 和 `SKILL.md` 里的路径

---

## 模型选择

- `--model small`（默认）：中文够用，速度快，Mac 本地跑顺畅
- `--model medium`：更准但慢 2-3 倍，风扇会转
- `--model tiny`：快到飞起但精度掉，只适合粗糙草稿

中文会议默认 small 就行。

---

## 常见问题

**Q：录不到声音？**
A：脚本会自动检测默认麦克风。如果检测错了，跟 CC 说"列一下我的音频设备"，然后指定 `--audio-device 数字`。

**Q：转写里出现"请订阅、点赞"之类的胡话？**
A：那是 Whisper 在静音段的幻觉，脚本已经过滤掉常见的几个关键词。如果漏了新的，把原文发给 CC 让他加到 `hallucination_keywords` 列表里。

**Q：想要会议处理流水线？**
A：只有这个包是不够的，还需要 Vivian 的完整流水线配置。让 CC 读一下 `pipelines.md`（如果没有就跟 Vivian 要），或者自己让 CC 根据会议转写生成纪要。

---

## 文件清单

```
recording-skill/
├── README.md                              ← 本文件
├── .claude/skills/recording/SKILL.md      ← skill 定义（CC 自动读取）
└── _tools/live_transcribe.py              ← 实时转写脚本
```

---

有问题问 Vivian 或者直接问你的 CC。祝玩得愉快 🎙️
