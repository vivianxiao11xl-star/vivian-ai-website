---
name: recording
description: 录音→转写→会议处理全自动流水线。当用户说"录音，XX"时启动Mac麦克风实时录音+实时转写（边说边出文字），说"停"时停止并自动触发会议处理流水线②。也可以直接处理已有的音频文件。
---

# 🎙️ 录音 Skill

实时录音 + 实时转写（边说边出文字）→ 自动触发会议处理流水线。

## 依赖工具

- `_tools/live_transcribe.py`：实时录音+转写脚本（PyAudio + SpeechRecognition + Whisper）
- `whisper`（openai-whisper）：本地语音转文字
- `ffmpeg`：同步录制 MP3
- 会议处理流水线②：见 `.claude/pipelines.md`

### 首次使用（同学第一次跑这个 skill 时）

直接跟 CC 说 **"装一下录音 skill 的依赖"**，CC 会自动完成：

```bash
pip install openai-whisper SpeechRecognition pyaudio numpy
brew install ffmpeg portaudio   # macOS
```

跑不通时把报错丢给 CC，让 CC 判断是缺什么。

### 换 vault / 换路径

脚本默认把录音存到 `01-一号位AI进化论/07-沟通录音/`。如果你的 vault 结构不一样：

- 临时：加 `--output-dir "你的路径"`
- 长期：让 CC 改 `_tools/live_transcribe.py` 里的默认路径，或改本文件里"方式一"的启动命令

## 使用方式

### 方式一：实时录音转写（"录音，XX"）— 首选方式

用户说 **"录音，XX"**（XX=客户名）时：

1. **先检查是否已有录音进程在跑**（`pgrep -f live_transcribe`），如果有就不要重复启动
2. 启动实时转写（边录边出文字）：
   ```bash
   python3 _tools/live_transcribe.py "客户名" --model small
   ```
3. 脚本在后台运行（用 `run_in_background`），实时输出转写文字
4. 同时自动录制 MP3 音频文件作为备份
5. 转写文本自动保存到 `01-一号位AI进化论/07-沟通录音/YYYYMMDD_HHMMSS-客户名-实时转写.md`
6. 录音文件保存到 `01-一号位AI进化论/07-沟通录音/YYYYMMDD_HHMMSS-客户名.mp3`

用户说 **"停"** 时：
- 发送中断信号停止脚本
- 读取转写 .md 文件
- **自动触发会议处理流水线②**（不用用户再说一遍）

### 方式二：处理已有音频文件

用户丢了一个音频文件（.mp3/.m4a/.wav/.ogg/.webm）时：

1. 确认客户名（如果用户没说，问一句"这是和谁的会议？"）
2. 用 whisper 离线转写：
   ```bash
   python3 -m whisper "音频路径" --model small --language Chinese --output_format txt --output_dir "输出目录"
   ```
3. 自动触发会议处理流水线②

### 方式三：处理已有转写文本

用户丢了 .md/.txt 且内容像对话转写 → 跳过转写，直接触发流水线②

## 实时转写 vs 离线转写

| | 实时转写（方式一） | 离线转写（方式二） |
|---|---|---|
| 速度 | 边说边出文字 | 录完再等几分钟 |
| 用途 | 现场会议 | 处理已有录音文件 |
| 命令 | `python3 _tools/live_transcribe.py` | `python3 -m whisper` |

**默认用实时转写。** 只有在处理别人发来的音频文件时才用离线转写。

## 转写完成后

自动触发 **流水线②会议处理**，包括：
- Agent A：内部版会议纪要
- Agent B：客户版会议纪要（可直接发给客户）
- Agent C：朋友圈文案
- Agent D：客户档案更新（更新客户总览表）
- Agent E：跟进任务清单

**全程用户只需说"录音，XX"和"停"两句话。**

## 触发词匹配

以下任一表述都应触发此 Skill：
- "录音，XX" / "录音 XX" / "开始录音"
- "帮我录一下" / "开始录"
- 丢音频文件 + 任何包含"录音""会议""整理""转写"的消息
- "停" / "1" / "。" / "停止录音" / "好了" / "录完了"（停止录音时，任何一个字符都行）
