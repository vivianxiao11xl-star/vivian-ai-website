#!/usr/bin/env bash
# 🎙️ 录音 Skill · 卸载脚本
# 用法：bash uninstall.sh

set -e

SKILL_HOME="$HOME/.claude/skills/recording"

if [ -t 1 ]; then
  RED="\033[0;31m"; GREEN="\033[0;32m"; YELLOW="\033[1;33m"; NC="\033[0m"
else
  RED=""; GREEN=""; YELLOW=""; NC=""
fi

echo ""
echo "🎙️  录音 Skill · 卸载"
echo ""
echo "  即将删除：$SKILL_HOME"
echo "  这会同时删除："
echo "    - SKILL.md 和 live_transcribe.py"
echo "    - Python venv（~100MB）"
echo ""
echo -e "  ${YELLOW}不会删除：${NC}"
echo "    - Homebrew 和 ffmpeg/portaudio（可能被其他程序用）"
echo "    - ~/.cache/whisper/ 里的模型文件（500MB，想删自己 rm）"
echo "    - 已经录好的会议记录（在你的项目目录 recordings/ 下）"
echo ""

read -p "$(echo -e ${YELLOW}确认删除？[y/N]: ${NC})" reply
if [[ ! "$reply" =~ ^[Yy]$ ]]; then
  echo "已取消。"
  exit 0
fi

if [ -d "$SKILL_HOME" ]; then
  rm -rf "$SKILL_HOME"
  echo -e "${GREEN}✅ 已卸载${NC}"
else
  echo -e "${YELLOW}⚠️  $SKILL_HOME 不存在，无需卸载${NC}"
fi

echo ""
echo "  想连 Whisper 模型也删掉（省 500MB 硬盘）："
echo "    rm -rf ~/.cache/whisper/"
echo ""
