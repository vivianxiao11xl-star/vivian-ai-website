@echo off
REM ============================================================
REM  录音 Skill · Windows 一键安装（离线转写版）
REM
REM  说明：
REM    Windows 不支持实时麦克风录音（macOS 专属功能）
REM    所以 Windows 版只做「离线转写」：
REM      1. 你用手机/其他工具录音
REM      2. 把 mp3/m4a 文件丢给 Claude Code
REM      3. 这个 Skill 自动转写 + 出纪要
REM
REM  做什么：
REM    1. 检测 Python 3
REM    2. 检测/安装 ffmpeg（用 winget）
REM    3. 创建 venv：%USERPROFILE%\.claude\skills\recording\.venv
REM    4. 用阿里云 pip 源装 openai-whisper
REM    5. 预下载 Whisper small 模型
REM    6. 复制 SKILL.md 和脚本
REM ============================================================

setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1

echo.
echo ============================================================
echo   Recording Skill (Windows / Offline Transcription Mode)
echo ============================================================
echo.

REM ---------- 1. Python ----------
echo [1/6] Checking Python...
where python >nul 2>&1
if %errorlevel% neq 0 (
  echo    [X] Python not found.
  echo    Install: https://www.python.org/downloads/windows/
  echo    Make sure to check "Add Python to PATH" during install.
  pause
  exit /b 1
)
python --version
echo    [OK] Python found.
echo.

REM ---------- 2. ffmpeg ----------
echo [2/6] Checking ffmpeg...
where ffmpeg >nul 2>&1
if %errorlevel% neq 0 (
  echo    [!] ffmpeg not found. Trying winget install...
  winget install --silent --accept-package-agreements --accept-source-agreements Gyan.FFmpeg
  if !errorlevel! neq 0 (
    echo    [X] Failed to install ffmpeg via winget.
    echo    Manual install:
    echo      1. Download: https://www.gyan.dev/ffmpeg/builds/
    echo      2. Extract to C:\ffmpeg
    echo      3. Add C:\ffmpeg\bin to PATH
    pause
    exit /b 1
  )
  echo    [OK] ffmpeg installed. You may need to restart the terminal.
) else (
  echo    [OK] ffmpeg found.
)
echo.

REM ---------- 3. Skill directories ----------
echo [3/6] Creating Skill directories...
set SKILL_HOME=%USERPROFILE%\.claude\skills\recording
set VENV_DIR=%SKILL_HOME%\.venv
if not exist "%SKILL_HOME%" mkdir "%SKILL_HOME%"
if not exist "%SKILL_HOME%\tools" mkdir "%SKILL_HOME%\tools"
echo    [OK] %SKILL_HOME%
echo.

REM ---------- 4. venv ----------
echo [4/6] Creating Python venv...
if not exist "%VENV_DIR%" (
  python -m venv "%VENV_DIR%"
  echo    [OK] venv created.
) else (
  echo    [OK] venv already exists.
)
set VENV_PY=%VENV_DIR%\Scripts\python.exe
set VENV_PIP=%VENV_DIR%\Scripts\pip.exe
echo.

REM ---------- 5. Python packages ----------
echo [5/6] Installing Python packages (Alibaba mirror)...
"%VENV_PIP%" install --upgrade pip -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com --quiet
"%VENV_PIP%" install "numpy<2" "openai-whisper" -i https://mirrors.aliyun.com/pypi/simple/ --trusted-host mirrors.aliyun.com
if %errorlevel% neq 0 (
  echo    [X] pip install failed.
  pause
  exit /b 1
)
echo    [OK] Packages installed.
echo.

REM ---------- 6. Pre-download Whisper model ----------
REM Windows uses "small" (500MB) instead of "large-v3" (3GB) because:
REM   - Windows has no MPS (Apple Silicon GPU) acceleration
REM   - Pure CPU inference on large-v3 is painfully slow (10x realtime)
REM   - Small model is sufficient for offline transcription quality
echo [6/6] Pre-downloading Whisper small model (~500MB, one-time)...
"%VENV_PY%" -c "import whisper; whisper.load_model('small'); print('OK')"
if %errorlevel% neq 0 (
  echo    [!] Model download failed. Will retry on first use.
)
echo.

REM ---------- Deploy SKILL files ----------
copy /Y "%~dp0skill\SKILL.md" "%SKILL_HOME%\SKILL.md" >nul
copy /Y "%~dp0skill\tools\live_transcribe.py" "%SKILL_HOME%\tools\live_transcribe.py" >nul

REM Write a Windows-specific SKILL.md note
(
  echo ^> ⚠️ Windows 版为离线转写模式，不支持实时录音。
  echo ^> 用法：用手机/其他工具录好 mp3/m4a，丢给 Claude Code 让它转写。
  echo ^> Python venv: %VENV_DIR%
) > "%SKILL_HOME%\WINDOWS_README.md"

echo.
echo ============================================================
echo   Install Complete!
echo ============================================================
echo.
echo   Skill location: %SKILL_HOME%
echo.
echo   How to use:
echo     1. Record audio with your phone / any recorder (mp3/m4a)
echo     2. Open Claude Code, drop the audio file into chat
echo     3. Say: "Please transcribe this recording"
echo.
echo   Uninstall:
echo     rmdir /s /q "%SKILL_HOME%"
echo.
pause
