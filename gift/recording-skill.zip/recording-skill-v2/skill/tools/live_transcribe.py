# -*- coding: utf-8 -*-
"""
实时录音 + 实时转写（边说边出文字）

用法：
  python3 live_transcribe.py [客户名]
  python3 live_transcribe.py 民杰
  python3 live_transcribe.py 民杰 --model small   # 默认，速度与精度平衡
  python3 live_transcribe.py 民杰 --model medium  # 更准但稍慢
  python3 live_transcribe.py 民杰 --output-dir ./recordings  # 自定义输出目录

输出目录优先级（自动判断）：
  1. --output-dir 参数（显式指定）
  2. 环境变量 RECORDING_SKILL_OUTPUT_DIR
  3. 当前工作目录下的 recordings/（默认）

按 Ctrl+C 停止，自动保存完整文本到输出目录。
"""

import argparse
import io
import os
import sys
import time
import datetime
import threading
import queue
import tempfile
import numpy as np

import speech_recognition as sr

# Whisper 延迟加载
whisper_model = None

def load_whisper(model_name="small"):
    global whisper_model
    if whisper_model is None:
        import whisper
        print(f"⏳ 加载 Whisper {model_name} 模型（首次需下载）...")
        whisper_model = whisper.load_model(model_name)
        print(f"✅ 模型加载完成")
    return whisper_model


def _detect_audio_device():
    """自动检测 macOS 默认麦克风设备号"""
    import subprocess
    try:
        result = subprocess.run(
            ["ffmpeg", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
            capture_output=True, text=True, timeout=5
        )
        # ffmpeg 把设备列表输出到 stderr
        output = result.stderr
        # 找音频设备段（[AVFoundation audio devices:]之后的部分）
        in_audio = False
        for line in output.split("\n"):
            if "audio devices" in line.lower():
                in_audio = True
                continue
            if in_audio and "[" in line and "]" in line:
                # 提取第一个音频设备的编号，格式如 [AVFoundation indev @ ...] [0] MacBook Pro Microphone
                import re
                match = re.search(r'\[(\d+)\]', line)
                if match:
                    device_id = match.group(1)
                    print(f"🎤 检测到音频设备: {line.strip()} → 使用设备 :{device_id}")
                    return device_id
    except Exception:
        pass
    # 检测失败，回退默认值
    print("⚠️ 无法自动检测麦克风，使用默认设备 :0")
    return "0"


def main():
    parser = argparse.ArgumentParser(description="实时录音转写")
    parser.add_argument("client", nargs="?", default="未命名会议", help="客户/会议名称")
    parser.add_argument("--model", default="small", choices=["tiny", "base", "small", "medium"],
                        help="Whisper 模型大小（默认 small，中文推荐 small 或 medium）")
    parser.add_argument("--interval", type=int, default=5, help="转写间隔秒数（默认5秒）")
    parser.add_argument("--no-audio", action="store_true", help="不录MP3（默认录音，结束后可选删除）")
    parser.add_argument("--output-dir", default=None,
                        help="输出目录（默认：当前工作目录下的 recordings/）")
    parser.add_argument("--audio-device", default=None,
                        help="FFmpeg 录音设备号（不指定则自动检测默认麦克风）")
    args = parser.parse_args()

    # 输出路径优先级：--output-dir > 环境变量 > 当前工作目录/recordings
    if args.output_dir:
        output_dir = os.path.abspath(args.output_dir)
    elif os.environ.get("RECORDING_SKILL_OUTPUT_DIR"):
        output_dir = os.path.abspath(os.environ["RECORDING_SKILL_OUTPUT_DIR"])
    else:
        output_dir = os.path.abspath(os.path.join(os.getcwd(), "recordings"))
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    md_file = os.path.join(output_dir, f"{timestamp}-{args.client}-实时转写.md")
    audio_file = os.path.join(output_dir, f"{timestamp}-{args.client}.mp3")

    # 加载模型
    model = load_whisper(args.model)

    # 初始化麦克风
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 500
    recognizer.dynamic_energy_threshold = True
    recognizer.pause_threshold = 1.5

    mic = sr.Microphone(sample_rate=16000)

    # 校准环境噪音
    print("🎙️ 校准环境噪音...")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=2)
    print("✅ 校准完成")

    print(f"\n{'='*50}")
    print(f"🔴 实时转写已开始")
    print(f"   客户: {args.client}")
    print(f"   模型: Whisper {args.model}")
    print(f"   间隔: 每 {args.interval} 秒转写一次")
    print(f"   输出: {md_file}")
    print(f"   按 Ctrl+C 停止")
    print(f"{'='*50}\n")

    # 音频数据队列
    audio_queue = queue.Queue()
    all_text = []
    start_time = time.time()

    # 默认同时录 MP3（结束后由调用者决定是否删除）
    import subprocess
    ffmpeg_proc = None
    if not args.no_audio:
        # 自动检测音频设备（macOS）
        audio_device = args.audio_device
        if audio_device is None:
            audio_device = _detect_audio_device()
        ffmpeg_proc = subprocess.Popen(
            ["ffmpeg", "-f", "avfoundation", "-i", f":{audio_device}",
             "-ar", "16000", "-ac", "1", "-codec:a", "libmp3lame", "-b:a", "32k",
             audio_file, "-loglevel", "quiet", "-y"],
            stdin=subprocess.PIPE
        )

    def audio_callback(recognizer, audio):
        """每检测到一段语音就放入队列"""
        audio_queue.put(audio)

    # 开始后台监听
    stop_listening = recognizer.listen_in_background(mic, audio_callback, phrase_time_limit=args.interval)

    # 写 Markdown 头
    with open(md_file, "w", encoding="utf-8") as f:
        f.write(f"# {args.client} — 实时转写\n\n")
        f.write(f"> 时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"> 模型：Whisper {args.model}\n")
        f.write(f"> 录音：{os.path.basename(audio_file)}\n\n")
        f.write("---\n\n")

    try:
        while True:
            try:
                audio = audio_queue.get(timeout=1)
            except queue.Empty:
                continue

            # 将音频数据写入临时文件
            wav_data = audio.get_wav_data()
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                tmp.write(wav_data)
                tmp_path = tmp.name

            try:
                # Whisper 转写
                result = model.transcribe(
                    tmp_path,
                    language="zh",
                    fp16=False,
                    no_speech_threshold=0.6,
                    initial_prompt="以下是简体中文的会议对话记录。",
                )
                text = result["text"].strip()

                # 过滤 Whisper 静音幻觉（没人说话时的胡编）
                hallucination_keywords = [
                    "请点赞", "订阅", "转发", "打赏", "谢谢观看", "字幕",
                    "请不吝点赞", "明镜与点点", "支持明镜", "点点栏目",
                    "字幕君", "许多人许多人", "然后再按下", "点一下字幕",
                ]
                is_hallucination = any(kw in text for kw in hallucination_keywords)
                is_repetitive = len(set(text.split())) < len(text.split()) * 0.3  # 重复率超70%

                if text and not is_hallucination and not is_repetitive and len(text) > 2:
                    elapsed = time.time() - start_time
                    minutes = int(elapsed // 60)
                    seconds = int(elapsed % 60)
                    time_tag = f"[{minutes:02d}:{seconds:02d}]"

                    print(f"  {time_tag} {text}")
                    all_text.append(f"{time_tag} {text}")

                    # 追加到文件
                    with open(md_file, "a", encoding="utf-8") as f:
                        f.write(f"{time_tag} {text}\n\n")

            finally:
                os.unlink(tmp_path)

    except KeyboardInterrupt:
        print(f"\n\n⏹️  转写结束")

    # 清理
    stop_listening(wait_for_stop=False)
    if ffmpeg_proc and ffmpeg_proc.poll() is None:
        ffmpeg_proc.stdin.close()
        ffmpeg_proc.terminate()
        ffmpeg_proc.wait()

    # 写入完整文本
    elapsed_total = time.time() - start_time
    minutes_total = int(elapsed_total // 60)

    with open(md_file, "a", encoding="utf-8") as f:
        f.write(f"\n---\n\n")
        f.write(f"> 总时长：{minutes_total} 分钟\n")
        f.write(f"> 转写段数：{len(all_text)}\n")

    print(f"\n✅ 已保存：")
    print(f"   转写文本: {md_file}")
    if not args.no_audio:
        print(f"   完整录音: {audio_file}")
        print(f"   💡 如不需要录音文件，告诉我「删掉录音」即可")
    print(f"   时长: {minutes_total} 分钟")
    print(f"   段数: {len(all_text)}")


if __name__ == "__main__":
    main()
