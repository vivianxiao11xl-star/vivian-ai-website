# -*- coding: utf-8 -*-
from __future__ import annotations  # 兼容 Python 3.9（macOS 系统自带），允许 str | None 语法

"""
实时录音 + 实时转写（边说边出文字）

用法：
  python3 live_transcribe.py [客户名]
  python3 live_transcribe.py 民杰
  python3 live_transcribe.py 民杰 --model large-v3   # 默认，最高精度（需 3GB 模型）
  python3 live_transcribe.py 民杰 --model small      # 备用，下载小（500MB）
  python3 live_transcribe.py 民杰 --output-dir ./recordings

输出目录优先级（自动判断）：
  1. --output-dir 参数（显式指定）
  2. 环境变量 RECORDING_SKILL_OUTPUT_DIR
  3. 自动找 vault root（向上找 .obsidian 文件夹）→ vault_root/recordings/
  4. 当前工作目录下的 recordings/（兜底）

停止方式：
  - Ctrl+C
  - 外部 kill（脚本会写 PID 到 ~/.claude/skills/recording/.live_transcribe.pid，
    方便 SKILL.md 端的"停"指令发 SIGINT）
"""

import argparse
import atexit
import io
import os
import signal
import sys
import time
import datetime
import threading
import queue
import tempfile
import numpy as np

import speech_recognition as sr

# --- 全局 ---
whisper_model = None
ffmpeg_proc = None
stop_listening = None
PID_FILE = os.path.expanduser("~/.claude/skills/recording/.live_transcribe.pid")

# ---------- 模型加载（MPS 自动加速） ----------

def load_whisper(model_name="large-v3"):
    global whisper_model
    if whisper_model is None:
        import whisper
        import torch

        # 自动选 device：Apple Silicon MPS > CUDA > CPU
        if torch.backends.mps.is_available():
            device = "mps"
            device_label = "MPS (Apple Silicon GPU 加速)"
        elif torch.cuda.is_available():
            device = "cuda"
            device_label = "CUDA"
        else:
            device = "cpu"
            device_label = "CPU"

        print(f"⏳ 加载 Whisper {model_name} 模型（device={device_label}，首次下载约 3GB）...")
        try:
            whisper_model = whisper.load_model(model_name, device=device)
        except Exception as e:
            # MPS 某些 op 可能不支持，回退 CPU
            if device == "mps":
                print(f"⚠️ MPS 加载失败（{e}），回退到 CPU")
                whisper_model = whisper.load_model(model_name, device="cpu")
            else:
                raise
        print(f"✅ 模型加载完成")
    return whisper_model


# ---------- 输出目录：自动找 vault root ----------

def _find_vault_root(start_dir: str) -> str | None:
    """
    向上找 .obsidian 文件夹，找到就返回它的父目录（即 vault root）
    找不到返回 None
    """
    cur = os.path.abspath(start_dir)
    for _ in range(8):  # 最多往上找 8 层
        if os.path.isdir(os.path.join(cur, ".obsidian")):
            return cur
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return None


def _resolve_output_dir(args_output_dir: str | None) -> str:
    """解析输出目录，按优先级：参数 > env > vault root > cwd"""
    if args_output_dir:
        return os.path.abspath(args_output_dir)
    env_dir = os.environ.get("RECORDING_SKILL_OUTPUT_DIR")
    if env_dir:
        return os.path.abspath(env_dir)
    vault_root = _find_vault_root(os.getcwd())
    if vault_root:
        return os.path.join(vault_root, "recordings")
    return os.path.abspath(os.path.join(os.getcwd(), "recordings"))


# ---------- 音频设备检测 ----------

def _detect_audio_device():
    """自动检测 macOS 默认麦克风设备号"""
    import subprocess
    try:
        result = subprocess.run(
            ["ffmpeg", "-f", "avfoundation", "-list_devices", "true", "-i", ""],
            capture_output=True, text=True, timeout=5
        )
        output = result.stderr
        in_audio = False
        for line in output.split("\n"):
            if "audio devices" in line.lower():
                in_audio = True
                continue
            if in_audio and "[" in line and "]" in line:
                import re
                match = re.search(r'\[(\d+)\]', line)
                if match:
                    device_id = match.group(1)
                    print(f"🎤 检测到音频设备: {line.strip()} → 使用设备 :{device_id}")
                    return device_id
    except Exception:
        pass
    print("⚠️ 无法自动检测麦克风，使用默认设备 :0")
    return "0"


# ---------- 清理函数（原子化、可多次调用） ----------

_cleanup_done = False

def cleanup_all():
    """关掉 mic 后台线程 + 杀 ffmpeg + 删 PID 文件。可被信号/正常退出/atexit 多次触发，幂等。"""
    global _cleanup_done, ffmpeg_proc, stop_listening
    if _cleanup_done:
        return
    _cleanup_done = True

    # 1. 停麦克风后台监听线程（等它真正退出）
    if stop_listening:
        try:
            stop_listening(wait_for_stop=True)
        except Exception:
            pass

    # 2. 干掉 ffmpeg 录音进程（硬 kill 兜底）
    if ffmpeg_proc and ffmpeg_proc.poll() is None:
        try:
            # 先 q 退出（ffmpeg 可以用 stdin 发 q 优雅结束，保全 mp3 文件）
            if ffmpeg_proc.stdin:
                try:
                    ffmpeg_proc.stdin.write(b"q")
                    ffmpeg_proc.stdin.flush()
                    ffmpeg_proc.stdin.close()
                except Exception:
                    pass
            try:
                ffmpeg_proc.wait(timeout=3)
            except Exception:
                ffmpeg_proc.terminate()
                try:
                    ffmpeg_proc.wait(timeout=2)
                except Exception:
                    ffmpeg_proc.kill()  # 最后一招：SIGKILL
        except Exception:
            pass

    # 3. 删 PID 文件
    try:
        if os.path.exists(PID_FILE):
            os.remove(PID_FILE)
    except Exception:
        pass


def _signal_handler(signum, frame):
    """把 SIGINT/SIGTERM 转成 KeyboardInterrupt，走正常退出流程"""
    raise KeyboardInterrupt()


# ---------- 主流程 ----------

def main():
    global ffmpeg_proc, stop_listening

    parser = argparse.ArgumentParser(description="实时录音转写")
    parser.add_argument("client", nargs="?", default="未命名会议", help="客户/会议名称")
    parser.add_argument(
        "--model", default="large-v3",
        choices=["tiny", "base", "small", "medium", "large-v2", "large-v3"],
        help="Whisper 模型（默认 large-v3，中文最佳精度；带宽紧可用 small）"
    )
    parser.add_argument("--interval", type=int, default=5, help="转写间隔秒数（默认5秒）")
    parser.add_argument("--no-audio", action="store_true", help="不录MP3")
    parser.add_argument("--output-dir", default=None,
                        help="输出目录（默认：自动找 vault root/recordings）")
    parser.add_argument("--audio-device", default=None,
                        help="FFmpeg 录音设备号（不指定则自动检测）")
    args = parser.parse_args()

    # 注册信号 + 退出钩子（保证外部 kill 也能清理）
    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)
    atexit.register(cleanup_all)

    # 写 PID 文件（方便 SKILL.md 端的"停"指令精准 kill）
    os.makedirs(os.path.dirname(PID_FILE), exist_ok=True)
    with open(PID_FILE, "w") as f:
        f.write(str(os.getpid()))

    # 解析输出目录
    output_dir = _resolve_output_dir(args.output_dir)
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    md_file = os.path.join(output_dir, f"{timestamp}-{args.client}-实时转写.md")
    audio_file = os.path.join(output_dir, f"{timestamp}-{args.client}.mp3")

    # 加载模型（MPS 加速）
    model = load_whisper(args.model)

    # 麦克风初始化
    recognizer = sr.Recognizer()
    recognizer.energy_threshold = 500
    recognizer.dynamic_energy_threshold = True
    recognizer.pause_threshold = 1.5
    mic = sr.Microphone(sample_rate=16000)

    print("🎙️ 校准环境噪音...")
    with mic as source:
        recognizer.adjust_for_ambient_noise(source, duration=2)
    print("✅ 校准完成")

    print(f"\n{'='*50}")
    print(f"🔴 实时转写已开始")
    print(f"   客户: {args.client}")
    print(f"   模型: Whisper {args.model}")
    print(f"   间隔: 每 {args.interval} 秒转写一次")
    print(f"   输出: {md_file}")
    print(f"   PID:  {os.getpid()}")
    print(f"   停止: Ctrl+C  或  kill {os.getpid()}")
    print(f"{'='*50}\n")

    audio_queue = queue.Queue()
    all_text = []
    start_time = time.time()

    # 同时录 MP3
    import subprocess
    if not args.no_audio:
        audio_device = args.audio_device or _detect_audio_device()
        ffmpeg_proc = subprocess.Popen(
            ["ffmpeg", "-f", "avfoundation", "-i", f":{audio_device}",
             "-ar", "16000", "-ac", "1", "-codec:a", "libmp3lame", "-b:a", "32k",
             audio_file, "-loglevel", "quiet", "-y"],
            stdin=subprocess.PIPE
        )

    def audio_callback(recognizer, audio):
        audio_queue.put(audio)

    stop_listening = recognizer.listen_in_background(mic, audio_callback, phrase_time_limit=args.interval)

    # Markdown 头
    with open(md_file, "w", encoding="utf-8") as f:
        f.write(f"# {args.client} — 实时转写\n\n")
        f.write(f"> 时间：{datetime.datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"> 模型：Whisper {args.model}\n")
        f.write(f"> 录音：{os.path.basename(audio_file)}\n\n")
        f.write("---\n\n")

    try:
        while True:
            try:
                audio = audio_queue.get(timeout=1)
            except queue.Empty:
                continue

            wav_data = audio.get_wav_data()
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
                tmp.write(wav_data)
                tmp_path = tmp.name

            try:
                result = model.transcribe(
                    tmp_path,
                    language="zh",
                    fp16=False,
                    no_speech_threshold=0.6,
                    initial_prompt="以下是简体中文的会议对话记录。",
                )
                text = result["text"].strip()

                # 过滤 Whisper 静音幻觉
                hallucination_keywords = [
                    "请点赞", "订阅", "转发", "打赏", "谢谢观看", "字幕",
                    "请不吝点赞", "明镜与点点", "支持明镜", "点点栏目",
                    "字幕君", "许多人许多人", "然后再按下", "点一下字幕",
                ]
                is_hallucination = any(kw in text for kw in hallucination_keywords)
                words = text.split()
                is_repetitive = words and len(set(words)) < len(words) * 0.3

                if text and not is_hallucination and not is_repetitive and len(text) > 2:
                    elapsed = time.time() - start_time
                    time_tag = f"[{int(elapsed // 60):02d}:{int(elapsed % 60):02d}]"
                    print(f"  {time_tag} {text}")
                    all_text.append(f"{time_tag} {text}")
                    with open(md_file, "a", encoding="utf-8") as f:
                        f.write(f"{time_tag} {text}\n\n")
            finally:
                os.unlink(tmp_path)

    except KeyboardInterrupt:
        print(f"\n\n⏹️  转写结束，正在清理...")

    # 统一清理（关麦克风线程 + 杀 ffmpeg + 删 PID）
    cleanup_all()

    # 写入结尾
    elapsed_total = time.time() - start_time
    minutes_total = int(elapsed_total // 60)
    with open(md_file, "a", encoding="utf-8") as f:
        f.write(f"\n---\n\n")
        f.write(f"> 总时长：{minutes_total} 分钟\n")
        f.write(f"> 转写段数：{len(all_text)}\n")

    print(f"\n✅ 已保存：")
    print(f"   转写文本: {md_file}")
    if not args.no_audio:
        print(f"   完整录音: {audio_file}")
    print(f"   时长: {minutes_total} 分钟 · 段数: {len(all_text)}")


if __name__ == "__main__":
    main()
