---
name: recording
description: 录音→转写→会议处理全自动流水线。当用户说"录音，XX"时启动Mac麦克风实时录音+实时转写（边说边出文字），说"停"时停止。也可以直接处理已有的音频文件（mp3/m4a/wav）离线转写。这是一个全局 skill，在任何项目目录下都能用，录音默认存到 vault 或当前工作目录的 recordings/ 子目录。
---

# 🎙️ 录音 Skill（全局版）

实时录音 + 实时转写（边说边出文字，Whisper Large V3 + MPS 加速）→ 自动输出到 vault/recordings。

## 依赖工具

- `tools/live_transcribe.py`：实时录音+转写脚本（PyAudio + SpeechRecognition + Whisper）
- `whisper`（openai-whisper）：本地语音转文字（默认 large-v3）
- `ffmpeg`：同步录制 MP3

> 💡 **依赖已经由 install.sh 装在独立 venv 里**，不污染系统 Python。本 SKILL 里所有 `python3` 调用请**统一使用 venv 的绝对路径**：
> `~/.claude/skills/recording/.venv/bin/python3`

---

## 使用方式

### 方式一：实时录音转写（"录音，XX"）— 首选

用户说 **"录音，XX"**（XX=客户名）时：

1. **先检查是否已有录音进程在跑**：
   ```bash
   pgrep -f live_transcribe.py
   ```
   有输出就**不要重复启动**，提示用户"已在录音中"。

2. 启动实时转写（默认 large-v3，会自动走 MPS 加速）：
   ```bash
   ~/.claude/skills/recording/.venv/bin/python3 \
     ~/.claude/skills/recording/tools/live_transcribe.py "客户名"
   ```
   用 `run_in_background` 异步执行。

3. 录音和转写文本**自动保存到 vault 根目录的 `recordings/`**（脚本会自动找 `.obsidian` 文件夹定位 vault root），找不到 vault 就落到当前工作目录的 `recordings/`。

4. 文件命名：`YYYYMMDD_HHMMSS-客户名-实时转写.md` + `YYYYMMDD_HHMMSS-客户名.mp3`

### ⏹ 用户说 **"停"** 时 — 必须真正停掉录音进程！

**双保险停止流程**（按顺序执行）：

```bash
# Step 1: 发 SIGINT 给录音主进程（脚本的 signal handler 会触发正常清理）
PID=$(cat ~/.claude/skills/recording/.live_transcribe.pid 2>/dev/null)
if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
  kill -INT "$PID"
  # 最多等 5 秒让它自己清理（写完 md、关闭 mp3）
  for i in 1 2 3 4 5; do
    sleep 1
    kill -0 "$PID" 2>/dev/null || break
  done
fi

# Step 2: 兜底——万一主进程或 ffmpeg 还活着，强杀
pkill -f "live_transcribe.py" 2>/dev/null
pkill -f "ffmpeg.*avfoundation" 2>/dev/null

# Step 3: 确认已停
if pgrep -f live_transcribe.py > /dev/null || pgrep -f "ffmpeg.*avfoundation" > /dev/null; then
  echo "⚠️ 进程未完全退出，再 kill -9 一次"
  pkill -9 -f "live_transcribe.py" 2>/dev/null
  pkill -9 -f "ffmpeg.*avfoundation" 2>/dev/null
fi

# Step 4: 清 PID 文件
rm -f ~/.claude/skills/recording/.live_transcribe.pid
```

**关键**：停止后必须验证 `pgrep -f live_transcribe.py` 没有输出，否则电脑会一直在录。

**停止后**：
1. 读取最新的转写 .md 文件（vault/recordings/ 里按时间排序最新的那个）
2. 触发会议处理流水线（如用户已配置 `02-会议处理` Skill）

### 方式二：处理已有音频文件

用户丢了一个音频文件（.mp3/.m4a/.wav/.ogg/.webm）时：

1. 确认客户名（没说就问一句）
2. 用 whisper 离线转写（走 venv，默认 large-v3）：
   ```bash
   ~/.claude/skills/recording/.venv/bin/python3 -m whisper \
     "音频路径" --model large-v3 --language Chinese \
     --output_format txt --output_dir "./recordings"
   ```
3. 触发后续会议处理

### 方式三：处理已有转写文本

用户丢了 .md/.txt 且内容像对话转写 → 跳过转写，直接做会议纪要。

---

## 输出目录规则（重要）

脚本按以下优先级决定录音和转写文件的保存位置：

| 优先级 | 来源 | 示例 |
|--------|------|------|
| 1 | `--output-dir` 参数 | `--output-dir ~/Desktop/meetings` |
| 2 | 环境变量 `RECORDING_SKILL_OUTPUT_DIR` | `export RECORDING_SKILL_OUTPUT_DIR=~/Recordings` |
| 3 | **自动找 vault root**（向上找 `.obsidian` 文件夹）→ `vault_root/recordings/` | `<vault>/recordings/` |
| 4 | 兜底：当前工作目录下的 `recordings/` | `./recordings/` |

**💡 结果**：在 Obsidian vault 里跑 Claude Code，录音自动落到 vault 根目录的 `recordings/`，**不再乱跑到当前子文件夹**。

---

## 模型与加速（默认 large-v3 + MPS）

- 默认模型 **`large-v3`**（3GB，中文精度最高）
- 脚本自动检测 **Apple Silicon MPS**（M1/M2/M3/M4）并走 GPU 加速
- MPS 某些 op 不支持时自动回退 CPU，不会报错
- 备选模型（带宽紧/机器弱可换）：
  - `--model small`（500MB，速度快）
  - `--model medium`（1.5GB，速度与精度平衡）
  - `--model tiny`（75MB，草稿级）

---

## 触发词匹配

**开始录音**：
- "录音，XX" / "录音 XX" / "开始录音"
- "帮我录一下" / "开始录"

**处理已有音频**：
- 丢音频文件 + 任何包含"录音""会议""整理""转写"的消息
- "这是和 XX 的录音" / "帮我处理这个会议"

**停止录音**：
- "停" / "停止" / "停止录音" / "录完了" / "1" / "。" / "好了"

---

## 实时转写 vs 离线转写

|  | 实时转写（方式一） | 离线转写（方式二） |
|---|---|---|
| 速度 | 边说边出文字（MPS 加速下几乎实时） | 录完再等几分钟 |
| 用途 | 现场会议 | 处理已有录音文件 |
| 需要麦克风权限 | 是 | 否 |
| 平台 | **macOS only** | macOS + Windows |

**默认用实时转写。** 只有在处理别人发来的音频文件时才用离线转写。

---

## 常见问题处理

### 脚本启动失败
先检查 venv 是否存在：
```bash
ls ~/.claude/skills/recording/.venv/bin/python3
```
不存在 → 让用户运行 `~/.claude/skills/recording/install.sh` 重新安装。

### "停"了之后电脑还在录
绝对不能发生。如果发生了说明上面的"双保险停止流程"没跑完。再手动：
```bash
pkill -9 -f live_transcribe.py
pkill -9 -f "ffmpeg.*avfoundation"
```

### 录不到声音
先列出音频设备让用户确认：
```bash
ffmpeg -f avfoundation -list_devices true -i ""
```
然后用 `--audio-device 数字` 指定。

### 转写里有"请订阅、点赞"之类胡话
Whisper 静音段幻觉，脚本已过滤常见词。漏了新的就加到 `hallucination_keywords` 列表。

### Whisper 模型下载慢
large-v3 首次要下 3GB，在中国大陆可能慢。install.sh 已预下载。如果 install.sh 跳过了这步（带宽/时间限制），首次使用会自动下，等一次就行。
