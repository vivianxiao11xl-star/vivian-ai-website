---
name: recording
description: 录音→转写→会议处理全自动流水线。当用户说"录音，XX"时启动Mac麦克风实时录音+实时转写（边说边出文字），说"停"时停止。也可以直接处理已有的音频文件（mp3/m4a/wav）离线转写。这是一个全局 skill，在任何项目目录下都能用，录音默认存到当前工作目录的 recordings/ 子目录。
---

# 🎙️ 录音 Skill（全局版）

实时录音 + 实时转写（边说边出文字）→ 自动输出到当前工作目录。

## 依赖工具

- `tools/live_transcribe.py`：实时录音+转写脚本（PyAudio + SpeechRecognition + Whisper）
- `whisper`（openai-whisper）：本地语音转文字
- `ffmpeg`：同步录制 MP3

> 💡 **依赖已经由 install.sh 装在独立 venv 里**，不污染系统 Python。本 SKILL 里所有 `python3` 调用请**统一使用 venv 的绝对路径**：
> `~/.claude/skills/recording/.venv/bin/python3`
>
> 简写变量：`$RECORDING_PY`（install.sh 会写入 `~/.zshrc` / `~/.bashrc`）

---

## 使用方式

### 方式一：实时录音转写（"录音，XX"）— 首选

用户说 **"录音，XX"**（XX=客户名）时：

1. **先检查是否已有录音进程在跑**（`pgrep -f live_transcribe`），如果有就不要重复启动
2. 启动实时转写（用 venv 的 python + skill 目录的脚本）：
   ```bash
   ~/.claude/skills/recording/.venv/bin/python3 \
     ~/.claude/skills/recording/tools/live_transcribe.py "客户名" --model small
   ```
3. 脚本在后台运行（`run_in_background`），实时输出转写文字
4. 录音和转写文本**默认保存到当前工作目录下的 `recordings/` 子目录**
5. 文件命名：`YYYYMMDD_HHMMSS-客户名-实时转写.md` + `YYYYMMDD_HHMMSS-客户名.mp3`

用户说 **"停"** 时：
- 发送中断信号停止脚本
- 读取转写 .md 文件
- 触发会议处理流水线（如用户已配置）

### 方式二：处理已有音频文件

用户丢了一个音频文件（.mp3/.m4a/.wav/.ogg/.webm）时：

1. 确认客户名（没说就问一句）
2. 用 whisper 离线转写（走 venv）：
   ```bash
   ~/.claude/skills/recording/.venv/bin/python3 -m whisper \
     "音频路径" --model small --language Chinese \
     --output_format txt --output_dir "./recordings"
   ```
3. 触发后续会议处理

### 方式三：处理已有转写文本

用户丢了 .md/.txt 且内容像对话转写 → 跳过转写，直接做会议纪要。

---

## 输出目录规则（重要）

脚本按以下优先级决定录音和转写文件的保存位置：

| 优先级 | 来源 | 示例 |
|--------|------|------|
| 1 | `--output-dir` 参数 | `--output-dir ~/Desktop/meetings` |
| 2 | 环境变量 `RECORDING_SKILL_OUTPUT_DIR` | `export RECORDING_SKILL_OUTPUT_DIR=~/Recordings` |
| 3 | **当前工作目录下的 `recordings/`**（默认） | `./recordings/` |

**💡 结果**：在任何 Obsidian vault 或项目目录下跑 Claude Code，录音就会落到那个目录里，自动归档。

---

## 触发词匹配

以下任一表述都触发此 Skill：

**开始录音**：
- "录音，XX" / "录音 XX" / "开始录音"
- "帮我录一下" / "开始录"

**处理已有音频**：
- 丢音频文件 + 任何包含"录音""会议""整理""转写"的消息
- "这是和 XX 的录音" / "帮我处理这个会议"

**停止录音**：
- "停" / "停止" / "停止录音" / "录完了" / "1" / "。" / "好了"

---

## 实时转写 vs 离线转写

|  | 实时转写（方式一） | 离线转写（方式二） |
|---|---|---|
| 速度 | 边说边出文字 | 录完再等几分钟 |
| 用途 | 现场会议 | 处理已有录音文件 |
| 需要麦克风权限 | 是 | 否 |
| 平台 | **macOS only** | macOS + Windows |

**默认用实时转写。** 只有在处理别人发来的音频文件时才用离线转写。

---

## 常见问题处理

### 脚本启动失败
先检查 venv 是否存在：
```bash
ls ~/.claude/skills/recording/.venv/bin/python3
```
不存在 → 让用户运行 `~/.claude/skills/recording/install.sh` 重新安装。

### 录不到声音
先列出音频设备让用户确认：
```bash
ffmpeg -f avfoundation -list_devices true -i ""
```
然后用 `--audio-device 数字` 指定。

### 转写里有"请订阅、点赞"之类胡话
Whisper 静音段幻觉，脚本已过滤常见词。漏了新的就加到 `hallucination_keywords` 列表。

### Whisper 模型下载慢
首次运行要下 500MB，在中国大陆可能慢。install.sh 已预下载，正常情况下装完就不需要再下。

---

## 模型选择

- `--model small`（默认）：中文够用，速度快
- `--model medium`：更准但慢 2-3 倍，风扇会转
- `--model tiny`：快到飞起但精度掉，只适合草稿

中文会议默认 small 就行。
