# 🪟 Windows 用户看这里

## TL;DR

**Windows 不能实时录音**（这是技术限制，不是我们偷懒）——但你仍然可以用这个 Skill，只是用法不同。

---

## 为什么 Windows 不能实时录音

录音 Skill 的实时转写功能用了一个叫 **AVFoundation** 的音频框架，这是苹果专有的，Windows 上根本没有。要在 Windows 上做实时录音，需要重写整个录音模块（换成 WASAPI 或 DirectSound），工作量比 Skill 本身还大。

**但是**：99% 的使用场景其实不需要实时录音。

---

## Windows 的正确用法：离线转写

### 流程

```
  手机录音 App              Windows Claude Code
  ┌──────────┐              ┌─────────────────┐
  │ 录一段   │──── mp3 ────▶│ 拖进聊天框       │
  │ 会议     │              │                  │
  └──────────┘              │ 说"帮我处理"     │
                            │                  │
                            │ ✅ 自动转写     │
                            │ ✅ 自动出纪要    │
                            └─────────────────┘
```

### 1. 安装

双击 `install.bat`（或命令行跑）。

`install.bat` 会做：
- 检测 Python（没装的话给你下载链接）
- 自动装 ffmpeg（用 winget）
- 创建独立 Python 环境
- 装 openai-whisper
- 预下载 Whisper 模型

不需要装 pyaudio、portaudio（这些都是实时录音才要的，离线不要）。

### 2. 录音

用任何工具：
- **手机**：微信"按住说话"放出来？不行。用系统录音 App 或随手录
- **电脑**：Windows 自带的"录音机" App（开始菜单搜）、OBS、Audacity 都行
- **会议软件**：腾讯会议、飞书会议都支持录制 mp3

只要最后拿到一个 `.mp3` / `.m4a` / `.wav` / `.ogg` 文件就行。

### 3. 转写

打开 Claude Code，把音频文件拖进聊天框，说：

> 这是和 XX 的会议，帮我转写 + 出纪要

Claude Code 会自动：
1. 识别到音频文件
2. 调用本 Skill 的离线转写功能
3. 走 Whisper 转成文字（本地跑，不上云）
4. 继续跑你的会议处理流水线（如果装了）

---

## 如果一定要实时录音

你只有两条路：

1. **换 Mac**（工作坊学员里这是第一推荐）
2. **用手机实时录音 App**（很多 App 支持边录边转，录完导出 mp3 到电脑）

---

## 卸载

```batch
rmdir /s /q "%USERPROFILE%\.claude\skills\recording"
```

想把 Whisper 模型也删了（省 500MB 硬盘）：
```batch
rmdir /s /q "%USERPROFILE%\.cache\whisper"
```

---

## 问题怎么办

- Python 没装：去 https://www.python.org/downloads/ 装最新版，安装时**勾选 Add to PATH**
- ffmpeg 装不上：winget 失败的话手动下 https://www.gyan.dev/ffmpeg/builds/ 解压 + 加 PATH
- 转写出来是乱码：Whisper 把你的普通话识别成日语了，转写时加 `--language Chinese`
- 还是搞不定：30 天答疑群找 Vivian

---

*注：本 Skill 的 Windows 版本为"降级方案"，完整功能请用 macOS。*
