#!/usr/bin/env bash
# ============================================================
# 🎙️ 录音 Skill · 一键安装脚本（macOS）
#
# 用法：
#   bash install.sh
#
# 做什么：
#   1. 检测 macOS 版本
#   2. 检测/安装 Homebrew（中科大镜像加速）
#   3. brew install ffmpeg portaudio
#   4. 创建独立 Python venv：~/.claude/skills/recording/.venv
#   5. 阿里云 pip 源装依赖
#   6. 预下载 Whisper small 模型
#   7. 复制 SKILL.md 和脚本到 ~/.claude/skills/recording/
#   8. 打印验证命令
#
# 出错了：
#   重新跑一遍 bash install.sh 即可（幂等）
#   还不行：docs/安装失败怎么办.md
# ============================================================

set -e  # 任何命令失败立即退出

# ---------- 颜色输出 ----------
if [ -t 1 ]; then
  RED="\033[0;31m"; GREEN="\033[0;32m"; YELLOW="\033[1;33m"; BLUE="\033[0;34m"; BOLD="\033[1m"; NC="\033[0m"
else
  RED=""; GREEN=""; YELLOW=""; BLUE=""; BOLD=""; NC=""
fi

info()    { echo -e "${BLUE}ℹ️  $1${NC}"; }
success() { echo -e "${GREEN}✅ $1${NC}"; }
warn()    { echo -e "${YELLOW}⚠️  $1${NC}"; }
error()   { echo -e "${RED}❌ $1${NC}"; }
step()    { echo -e "\n${BOLD}${BLUE}▶ $1${NC}"; }

# ---------- 确定脚本所在目录 ----------
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SKILL_SRC="$SCRIPT_DIR/skill"
SKILL_HOME="$HOME/.claude/skills/recording"
VENV_DIR="$SKILL_HOME/.venv"

echo ""
echo "============================================================"
echo "  🎙️  录音 Skill · 一键安装（macOS）"
echo "============================================================"
echo ""

# ---------- 1. 检测系统 ----------
step "1/7 · 检查系统"

if [[ "$OSTYPE" != "darwin"* ]]; then
  error "此脚本只支持 macOS。Windows 用户请看 docs/Windows用户看这里.md"
  exit 1
fi

MACOS_VERSION=$(sw_vers -productVersion)
success "macOS $MACOS_VERSION"

# Python 3
if ! command -v python3 &> /dev/null; then
  error "找不到 python3。请先装 Python 3.10+：https://www.python.org/downloads/macos/"
  exit 1
fi
PY_VERSION=$(python3 --version | awk '{print $2}')
success "Python $PY_VERSION"

# ---------- 2. Homebrew ----------
step "2/7 · 检查 Homebrew"

if ! command -v brew &> /dev/null; then
  warn "未检测到 Homebrew。即将安装（用中科大镜像加速，约 2-5 分钟）..."
  echo ""
  read -p "$(echo -e ${YELLOW}是否继续？[Y/n]: ${NC})" reply
  if [[ "$reply" =~ ^[Nn]$ ]]; then
    error "取消安装。没有 Homebrew 无法继续。"
    exit 1
  fi

  # 用中科大镜像加速
  export HOMEBREW_BREW_GIT_REMOTE="https://mirrors.ustc.edu.cn/brew.git"
  export HOMEBREW_CORE_GIT_REMOTE="https://mirrors.ustc.edu.cn/homebrew-core.git"
  export HOMEBREW_BOTTLE_DOMAIN="https://mirrors.ustc.edu.cn/homebrew-bottles"

  # 官方安装脚本
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

  # 确保 brew 在 PATH 里
  if [ -d /opt/homebrew/bin ]; then
    eval "$(/opt/homebrew/bin/brew shellenv)"
  elif [ -d /usr/local/bin ]; then
    eval "$(/usr/local/bin/brew shellenv)"
  fi
fi
success "Homebrew $(brew --version | head -1 | awk '{print $2}')"

# ---------- 3. 系统依赖 ----------
step "3/7 · 安装系统依赖（ffmpeg + portaudio）"

BREW_NEEDED=()
if ! brew list ffmpeg &>/dev/null; then BREW_NEEDED+=("ffmpeg"); fi
if ! brew list portaudio &>/dev/null; then BREW_NEEDED+=("portaudio"); fi

if [ ${#BREW_NEEDED[@]} -eq 0 ]; then
  success "ffmpeg 和 portaudio 都已安装"
else
  info "即将安装：${BREW_NEEDED[*]}"
  brew install "${BREW_NEEDED[@]}"
  success "系统依赖装好"
fi

# ---------- 4. 创建 skill 目录 + venv ----------
step "4/7 · 创建 Skill 目录 + Python venv"

mkdir -p "$SKILL_HOME"
info "Skill 目录: $SKILL_HOME"

if [ ! -d "$VENV_DIR" ]; then
  python3 -m venv "$VENV_DIR"
  success "创建 venv: $VENV_DIR"
else
  success "venv 已存在: $VENV_DIR"
fi

# 激活 venv 用的 pip
VENV_PIP="$VENV_DIR/bin/pip"
VENV_PY="$VENV_DIR/bin/python3"

# ---------- 5. Python 依赖 ----------
step "5/7 · 安装 Python 依赖（阿里云镜像加速）"

PIP_INDEX="https://mirrors.aliyun.com/pypi/simple/"
PIP_HOST="mirrors.aliyun.com"

info "升级 pip..."
"$VENV_PIP" install --upgrade pip -i "$PIP_INDEX" --trusted-host "$PIP_HOST" --quiet

info "安装 numpy / SpeechRecognition / pyaudio / openai-whisper ..."
if [ -f "$SCRIPT_DIR/requirements.txt" ]; then
  "$VENV_PIP" install -r "$SCRIPT_DIR/requirements.txt" \
    -i "$PIP_INDEX" --trusted-host "$PIP_HOST"
else
  "$VENV_PIP" install \
    "numpy<2" "SpeechRecognition" "pyaudio" "openai-whisper" \
    -i "$PIP_INDEX" --trusted-host "$PIP_HOST"
fi
success "Python 依赖装好"

# ---------- 6. 预下载 Whisper 模型 ----------
step "6/7 · 预下载 Whisper large-v3 模型（约 3GB，一次性）"

info "Large-V3 是中文精度最高的模型，配合 MPS（Apple Silicon GPU）加速几乎实时"
info "国内带宽正常 5-10 分钟，弱网可能更久。中途断了重跑本脚本即可续传。"

"$VENV_PY" -c "
import whisper
import torch

print('⏳ 下载 Whisper large-v3 模型（3GB，一次性）...')
# device=cpu 加载一次即可缓存，实际运行时脚本自己选 MPS
whisper.load_model('large-v3', device='cpu')
print('✅ 模型已缓存到 ~/.cache/whisper/large-v3.pt')

# 打印 MPS 是否可用
if torch.backends.mps.is_available():
    print('🚀 检测到 Apple Silicon MPS，实际使用时将自动 GPU 加速')
else:
    print('ℹ️  非 Apple Silicon，将用 CPU 推理（large-v3 在 CPU 上会慢，建议切 small）')
"
success "模型就绪"

# ---------- 7. 复制 SKILL.md 和脚本 ----------
step "7/7 · 部署 Skill 文件"

cp -f "$SKILL_SRC/SKILL.md" "$SKILL_HOME/SKILL.md"
mkdir -p "$SKILL_HOME/tools"
cp -f "$SKILL_SRC/tools/live_transcribe.py" "$SKILL_HOME/tools/live_transcribe.py"
chmod +x "$SKILL_HOME/tools/live_transcribe.py"

# 同时把 install.sh 也放进去，方便用户未来重装
cp -f "$SCRIPT_DIR/install.sh" "$SKILL_HOME/install.sh"
if [ -f "$SCRIPT_DIR/uninstall.sh" ]; then
  cp -f "$SCRIPT_DIR/uninstall.sh" "$SKILL_HOME/uninstall.sh"
fi

success "Skill 已部署到 $SKILL_HOME"

# ---------- 安装完成 ----------
echo ""
echo "============================================================"
echo -e "  ${GREEN}${BOLD}🎉 安装完成！${NC}"
echo "============================================================"
echo ""
echo "  Skill 位置：  $SKILL_HOME"
echo "  Python venv：$VENV_DIR"
echo ""
echo -e "  ${BOLD}接下来怎么验证？${NC}"
echo ""
echo "  1. 打开 Claude Code（Obsidian 插件或独立 CLI），在任意项目里输入："
echo ""
echo -e "       ${YELLOW}录音，测试${NC}"
echo ""
echo "  2. Claude 会启动麦克风（macOS 首次会弹窗问麦克风权限，点允许）"
echo "     说两句话，然后输入：停"
echo ""
echo "  3. 录音会自动存到 ${BOLD}vault 根目录/recordings/${NC}（自动找 .obsidian）"
echo "     找不到 vault 就落到当前工作目录/recordings/"
echo ""
echo -e "  ${BOLD}卸载？${NC}"
echo "     bash $SKILL_HOME/uninstall.sh"
echo ""
echo -e "  ${BOLD}出问题了？${NC}"
echo "     重跑本脚本（幂等）： bash $0"
echo "     还不行：看 docs/安装失败怎么办.md"
echo ""
