# 🎙️ 录音 Skill（全局版）

> 来自 Vivian 的工作流 · Claude Code Skill
> 说一句"录音，XX"就开始录音，说"停"就停，自动转写成会议纪要。

---

## 这是什么

一个 **Claude Code 全局 Skill**，装一次，在**任何项目目录**下都能用。

**Mac 版**：用麦克风实时录音，边录边转写（Whisper Large V3 + MPS GPU 加速，本地跑，不上云）
**Windows 版**：离线转写（用手机录好 mp3 → 丢给 Claude Code 自动转写，Whisper Small 模型）

两个版本都：**录音自动存到 vault 根目录的 `recordings/`**（脚本会找 `.obsidian` 文件夹定位 vault root；找不到时才回退到当前工作目录）。

---

## 快速安装

### macOS（实时录音 + 离线转写）

```bash
cd 解压出来的 recording-skill-v2 目录
bash install.sh
```

安装过程做这 7 件事：
1. 检测 macOS / Python
2. 自动装 Homebrew（中科大镜像加速）
3. 装 ffmpeg 和 portaudio
4. 创建独立 Python venv（不污染系统）
5. 用阿里云镜像装 openai-whisper 等依赖
6. 预下载 Whisper **large-v3** 模型（~3GB，首次需要 5-10 分钟）
7. 部署 SKILL 文件到 `~/.claude/skills/recording/`

> 💡 **为什么默认用 large-v3**：配合 Apple Silicon 的 MPS GPU 加速，实时转写几乎无延迟，中文精度业内最高。
> 非 Apple Silicon 或带宽紧的话，装完可以改用 `small`（500MB）。

**完成后**，在任何 Obsidian vault 或项目目录下打开 Claude Code，说：

> 录音，测试

即可开始。

### Windows（仅离线转写）

双击 `install.bat` 或：

```batch
install.bat
```

装完后，把手机录好的 mp3/m4a 丢给 Claude Code，说"帮我处理这个会议"。

---

## 安装后的目录

```
~/.claude/skills/recording/       ← macOS
%USERPROFILE%\.claude\skills\recording\   ← Windows
├── SKILL.md                      ← Claude Code 自动读取
├── tools/
│   └── live_transcribe.py        ← 录音脚本
├── .venv/                        ← 独立 Python 环境（不污染系统）
├── install.sh / install.bat      ← 可以重跑重装
└── uninstall.sh                  ← 卸载脚本
```

**全局可用**：装在用户家目录下，不管你在哪个项目里打开 Claude Code，这个 Skill 都可用。

---

## 怎么用

### 实时录音（macOS）

```
你：录音，张三

CC：（启动麦克风，开始转写）
    [00:05] 好我们开始今天的会议，主要议题是...
    [00:15] 我觉得我们可以从这几个方向...

你：停

CC：✅ 录音完成，已保存到 <vault>/recordings/20260419_143022-张三-实时转写.md
    （如果你装了会议处理流水线，会自动出纪要）
```

> ⚠️ 说"停"之后**必须真的停了**：脚本走"SIGINT → pkill → pkill -9"三段式兜底，确保麦克风和 ffmpeg 进程都关闭。万一电脑还在录音，手动 `pkill -9 -f live_transcribe.py`。

### 离线转写（两个平台都行）

```
你：（把手机录好的 mp3 文件拖进聊天框）这是和李四的录音

CC：（后台跑 whisper）...
    ✅ 转写完成
```

---

## 常见问题

### Q：装 Homebrew 那一步卡住了？
A：国内网络波动很正常。script 用了中科大镜像（mirrors.ustc.edu.cn），已经比官方快很多。实在不行重跑 `bash install.sh`，幂等的。

### Q：pip 装 pyaudio 失败？
A：99% 是 portaudio 没装好。脚本会自动 `brew install portaudio`，如果还报错，手动跑一下：
```bash
brew reinstall portaudio
~/.claude/skills/recording/.venv/bin/pip install --force-reinstall pyaudio
```

### Q：录音没声音？
A：macOS 首次用麦克风会弹窗问权限，点允许。已经点过拒绝 → 系统设置 → 隐私与安全性 → 麦克风 → 勾选 Terminal / iTerm / Claude Code。

### Q：Whisper 转写里出现"请订阅、点赞"？
A：Whisper 静音段的幻觉，脚本已过滤常见词。漏了告诉我。

### Q：想换默认模型（tiny/base/small/medium/large-v3）？
A：开 `~/.claude/skills/recording/SKILL.md`，搜 `--model large-v3` 改成你要的。可选：
- `tiny`（75MB，草稿）· `small`（500MB，均衡）· `medium`（1.5GB）· `large-v3`（3GB，最准，默认）

### Q：说"停"了但电脑还在录音怎么办？
A：肯定是进程没 kill 干净。手动：
```bash
pkill -9 -f live_transcribe.py
pkill -9 -f "ffmpeg.*avfoundation"
```
然后反馈给 Vivian——这个问题早期版本出现过，现在脚本有 PID 文件和 pkill 兜底，不应该再出现。

### Q：想卸载？
A：`bash ~/.claude/skills/recording/uninstall.sh`（macOS）。

更多疑难杂症看 `docs/安装失败怎么办.md`。

---

## 谁做的 / 反馈

- 设计：Vivian（[vivianai.cn](https://vivianai.cn)）
- 打包：Claudian（Claude Code）
- 版本：v2.0（全局 Skill 架构）· 2026-04-16

有问题来 30 天答疑群找 Vivian 或 CC。

---

## 许可

工作坊学员专用，欢迎自用 + 改造。禁止二次分发收费。
